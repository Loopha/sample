<html>
<body>
<?php 
 require_once "connect.php";
$query = "SELECT * FROM store";
$sql = "SHOW COLUMNS FROM store";
$result = mysqli_query($connect,$sql);
if($row = mysqli_fetch_array($result)){
    echo '<table border="0" cellspacing="2" cellpadding="2"> 
    <tr> 
        <td>'.'Type'.'</td> 
        <td> '.'Unit'.'</td> 
    </tr>';
}
if ($result = $connect->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $type = $row["Type"];
        $unit = $row["unit"];
        echo '<tr> 
                  <td>'.$type.'</td> 
                  <td>'.$unit.'</td> 
              </tr>';
    }
    $result->free();
} 
?>
</body>
</html>