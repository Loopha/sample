<?php 
require_once "connect.php";
if(isset($_POST['submit'])){
      $name = $_POST['name'];
      $address = $_POST['address'];
      $phone = $_POST['phone'];
      $email = $_POST['email'];
      //generating a password.
    $inf = "$name$email$phone$address!#$%^&*(){}][";
    $genereated_password =substr(str_shuffle($inf),0,8);
  $query = "INSERT INTO `hospital`(`Hospital_Name`, `Address`, `phone_no`, `email`,`password`) VALUES ('$name','$address','$phone','$email','$genereated_password')";
  $result= mysqli_query ($connect,$query);
  if($result){
     echo "<script>alert('Registerred successfully')</script>";
  }
}
?> 

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Hospital</title>
    <link rel="stylesheet" href="register.css">
</head>
<body>
<header class = "header">
      <div class="header__links hide-for-mobile">
      <div class="nav">
          <a href="#" class = "logo">
          <img width = 150px height = 50px class="logo-image" src="images/blood.jpg" alt="">
          </a>
          <span class="main-name">Blood Bank</span>   
        <ul>
          <li><a href="admin.php">Home</a></li>
          <li><a href="#">Services <i class="fas fa-caret-down"></i></a>

            <ul class = "submenu">

              <li><a href="#.php">Donors</a>
                  <ul class = "submenu2">
                    <li><a href="Donor.php">Register </a></li>
                    <li><a href="search.php">Update</a></li>
                  </ul>
            </li>
              <li><a href="#.php">Hospital</a>
                  <ul class = "submenu2">
                    <li><a href="register_hos.php">Register</a></li>
                    <li><a href="update_hos.php">Update</a></li>
                  </ul>
            </li>
              <li><a href="#.php">Camp</a>
                    <ul class = "submenu2">
                      <li><a href="register_camp.php">Register</a></li>
                      <li><a href="update_camp.php">Update</a></li>
                    </ul>
            </li>
             
            </ul>
          </li>
          <li class = "notify-li"><a href="#" class = "dropdown-toggle" id = "notify"><span class="count" style = "color:black; margin-right:5px; border-radius:50%;"></span>Notification  
          <ul class="dropdown-menu"></ul></a>
          </li>
          <!-- <li><a href="#">Contact Us</a></li> -->
          <li><a href="index.php">Log Out</a></li>
        </ul>
      </div>
      </div>
   </header>   
    <div class="head">
        <h1>Register Hospital</h1>
    </div>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form">
            <div class="left">
                <span>Hospital Name</span><input type="text" name="name" placeholder="Hospital_Name">
                <span>Address</span><input type="text" name="address" placeholder="Address">
                <span>Phone Number</span><input type="text" name="phone" placeholder="Phone">
                <span>Email</span><input type="text" name="email" placeholder="Email">
            </div>
            <button type="submit" name="submit">Submit</button>
        </div>
    </form>
</body>
<style>
    .header__links {
  margin: 0 auto;
}
.nav {
  height: 60px;
  background: white;
  box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
}
.logo {
  width: 200px;
}
.logo-image {
  padding: 5px 0 0 80px;
  width: 150px;
  height: 50px;
}
.main-name {
  font-size: 50px;
  font-weight: 700;
  color: rgb(166, 16, 30);
  font-family: "Gill Sans", "Gill Sans MT", Calibri, "Trebuchet MS", sans-serif;
  font-style: italic;
}
.nav ul {
  padding: 0;
  margin: 0;
  float: right;
  margin-right: 30px;
}
.nav ul li {
  /* background: rgb(166,16,30); */
  position: relative;
  list-style: none;
  display: inline-block;
}
.nav ul li a {
  display: block;
  padding: 0 15px;
  color: rgb(166, 16, 30);
  text-decoration: none;
  line-height: 60px;
  font-size: 20px;
  font-weight: 700;
}

.nav ul li a:hover {
  background: rgb(247, 239, 239);
  border-radius: 5px;
  color: rgb(166, 16, 30);
  transition: color 300ms ease-in-out;
}

.nav ul ul {
  position: absolute;
  top: 60px;
  display: none;
  z-index: 4;
}
.nav ul li:hover > ul {
  display: block;
}
.nav ul ul li {
  width: 150px;
  float: none;
  display: list-item;
  position: relative;
}
.nav ul li:hover > .dropdown-menu {
  display: none;
}
ul ul ul {
  left: 100%;
  top: 0;
}
.submenu2 {
  position: absolute;
  margin-top: 10px;
  margin-left: 200px;
}
ul li .submenu li:hover .submenu2 a {
  color: rgb(146, 32, 17);
  background-color: #fff;
}
ul li .submenu li .submenu2 li:hover a {
  color: rgb(130, 171, 238);
}
.submenu2 {
  display: hidden;
}
.submenu li:hover .submenu2 {
  display: block;
}
#notify:active > ul {
  display: block;
}
#notify:focus > ul {
  display: block;
}
.nav ul .dropdown-menu li {
  width: 150px;
  float: none;
  display: list-item;
  position: relative;
}
</style>

</html>
