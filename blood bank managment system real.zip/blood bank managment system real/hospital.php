<!DOCTYPE html>
<html lang="en">
    <head>
        <title>hospital home page </title>
        <link rel="stylesheet " href="hospital.css">
        <link rel="stylesheet " href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        </head>
    <body>
        <header>
        <div class="menu"> 
       <ul>
        <li class="active "><a href="#"><i class="fa fa-home"></i> HOME</a></li>
        <li><a href="#"><i class="fa fa-person"></i>DONOR</a>
              <div class="sub-menu-1">
                 <ul> 
                    <li><a href="donor_hos.php"><i class="fas fa-user-plus"></i></i>add</a></li>
                    <li><a href="donorup_hos.php"><i class="far fa-edit"></i></i>update</a></li> 
                </ul>
              </div>
        </li>
        <li><a href="request.php"><i class="fa fa-share"></i>REQUEST</a></li>
        <li><a href="#"><i class="fa fa-sticky-note"></i>REPORT</a></li>
        <li><a href="index.php"><i class="fa fa-sign-out-alt"></i>LOGOUT</a></li>
       </ul>
        </div>   
        </header>  
    </body>
</html>