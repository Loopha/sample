<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Camp home page  </title>
        <link rel="stylesheet " href="camp.css">
        </head>
    <body>
         <div class="name" >
             <nav class="navbar">
                 <ul>
                     <li><a class="active" href="#">HOME</a>
                        <li><a href="#"><i class="fa fa-person"></i>DONOR</a>
                            <div class="sub-menu-1">
                               <ul>                              
                                  <li><a href="donor_camp.php"><i class="fas fa-user-plus"></i></i>add</a></li>
                                  <li><a href="donorup_camp.php"><i class="far fa-edit"></i></i>update</a></li> 
                              </ul>
                            </div>
                      </li>
                            <li><a href="#">REPORT</a>
                                <li><a href="login.php">LOGOUT</a> 
                     </li>
                 </ul>
             </nav>
             </div>
        </div>     
   
       
    </body>
</html>