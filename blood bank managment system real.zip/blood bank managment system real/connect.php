<?php 
//connect to the database
$host = "localhost";
$pass= "";
$user = "root";
$dbname = "donate";
$connect = mysqli_connect($host,$user,$pass,$dbname);
?>