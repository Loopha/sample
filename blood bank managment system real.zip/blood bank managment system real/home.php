
<?php
require_once "connect.php";
$msg1 = "";
$msg2 = "";
$msg3 = "";
$msg4 = "";
$msg5 = "";
$msg6 = "";
$msg7 = "";
$msg8 = "";
if(isset($_POST["checkA+"])){
    $Type = "A+";
    $query="SELECT unit from store WHERE `Type` = '$Type'"; 
    $result = mysqli_query($connect,$query);
    $row = mysqli_fetch_array($result);
    if($row["unit"]>0){
        $msg1 = "Available";
    }
    else{
       $msg1 = "Not Available"; 
    }
}
elseif(isset($_POST["checkB+"])){
    $Type = "B+";
    $query="SELECT unit from store WHERE `Type` = '$Type'"; 
    $result = mysqli_query($connect,$query);
    $row = mysqli_fetch_array($result);
    if($row["unit"]>0){
        $msg2 = "Available";
    }
    else{
       $msg2 = "Not Available"; 
    }  
}
elseif(isset($_POST["checkAB+"])){
    $Type = "AB+";
    $query="SELECT unit from store WHERE `Type` = '$Type'"; 
    $result = mysqli_query($connect,$query);
    $row = mysqli_fetch_array($result);
 
    if($row["unit"]>0){
        $msg3 = "Available";
    }
    else{
       $msg3 = "Not Available"; 
    }
}
elseif(isset($_POST["checkO+"])){
    $Type = "O+";
    $query="SELECT unit from store WHERE `Type` = '$Type'"; 
    $result = mysqli_query($connect,$query);
    $row = mysqli_fetch_array($result);
    if($row["unit"]>0){
        $msg4 = "Available";
    }
    else{
       $msg4 = "Not Available"; 
    }
}
elseif(isset($_POST["checkA-"])){
    $Type = "A-";
    $query="SELECT unit from store WHERE `Type` = '$Type'"; 
    $result = mysqli_query($connect,$query);
    $row = mysqli_fetch_array($result);
   
    if($row["unit"]>0){
        $msg5 = "Available";
    }
    else{
       $msg5 = "Not Available"; 
    }
}   
elseif(isset($_POST["checkB-"])){
    $Type = "B-";
    $query="SELECT unit from store WHERE `Type` = '$Type'"; 
    $result = mysqli_query($connect,$query);
    $row = mysqli_fetch_array($result);

    if($row["unit"]>0){
        $msg6 = "Available";
    }
    else{
       $msg6 = "Not Available"; 
    }  
}
elseif(isset($_POST["checkAB-"])){
    $Type = "AB-";
    $query="SELECT unit from store WHERE `Type` = '$Type'"; 
    $result = mysqli_query($connect,$query);
    $row = mysqli_fetch_array($result);
   
    if($row["unit"]>0){
        $msg7 = "Available";
    }
    else{
       $msg7 = "Not Available"; 
    }
}
elseif(isset($_POST["checkO-"])){
    $Type = "O-";
    $query="SELECT unit from store WHERE `Type` = '$Type'"; 
    $result = mysqli_query($connect,$query);
    $row = mysqli_fetch_array($result);
    
    if($row["unit"]>0){
        $msg8 = "Available";
    }
    else{
       $msg8 = "Not Available"; 
    }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="home.css">
    <title>Document</title>
</head>
<body>
    <nav>
        <span><h1>LOGO</h1></span>
        <div class = "mainmenu">
                <a href="">Home</a>
                <a href="">About Us</a>
                <a href="">Contact Us</a>
                <a href="">login</a>
        </div>
</nav>
</header>
    <main>
        <div class="image">
        <!-- <img src="best.jpg" alt="" srcset=""> -->
        </div>
        <div class="main-container">

        <div class="container">
        <form action="" method="post">
        
           <button class="button" type="submit" name="checkA+"><h1>A+</h1></button> 
           <div class="message"><?php echo $msg1;?></div>
        
        </form>
        </div> 
        <div class="container">
        <form action="" method="post">
           
            <button class="button" type="submit" name="checkB+"><h1>B+</h1></button> 
            <div class="message"><?php echo $msg2;?></div>
          
        </form>
        </div>
        <div class="container">
        <form action="" method="post">
           
            <button class="button" type="submit" name="checkAB+"><h1>AB+</h1></button> 
            <div class="message"><?php echo $msg3;?></div>
            
        </form>
        </div> 
        <div class="container">
        <form action="" method="post">
           
            <button class="button" type="submit" name="checkO+"><h1>O+</h1></button> 
            <div class="message"><?php echo $msg4;?></div>
           
        </form>
        </div>
        <div class="container">
        <form action="" method="post">
            
            <button class="button" type="submit" name="checkA-"><h1>A-</h1></button> 
            <div class="message"><?php echo $msg5;?></div>
       
        </form>
        </div>
        <div class="container">
        <form action="" method="post">
            
            <button class="button" type="submit" name="checkB-"><h1>B-</h1></button> 
            <div class="message"><?php echo $msg6;?></div>
           
        </form>
        </div>
        <div class="container">
        <form action="" method="post">
            
            <button class="button" type="submit" name="checkAB-"><h1>AB-</h1></button> 
            <div class="message"><?php echo $msg7;?></div>
            
        </form>
        </div>
        <div class="container">
        <form action="" method="post">
         
            <button class ="button" type="submit" name="checkO-"><h1>O-</h1></button> 
            <div class="message"><?php echo $msg8;?></div>
            
        </form>
        </div>

        </div>
    </main>
    <footer>

    </footer>

</body>
</html>