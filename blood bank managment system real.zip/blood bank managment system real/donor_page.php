<?php 
//declare values
    session_start();

    require_once "connect.php";
    $password= $_SESSION['password'];
    $name = $_SESSION['name'];
    //retrive from the database.
    $query = "SELECT * FROM donors WHERE `password` = '$password' AND `name` = '$name'";
     if (!$query){
        echo "invalid email or password";
    }
    $result = mysqli_query ($connect,$query);    
    while( $row = mysqli_fetch_array($result)){
        $id = $row ["id"];
        $name = $row ["name"];
        $age = $row ["age"];
        $sex = $row ["sex"];
        $type = $row ["type"];
        $many = $row ["how many"];
        $unit = $row ["unit"];
        $email = $row ["email"];
        $phone = $row ["phone"];
        $address = $row ["address"];
        $image = $row ["image"];   
        $date = $row ["date"]; 
        $qr = $row["Qr code"];
    }  
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="person.css?v=<?php echo time(); ?>">
    <title>personal information</title>
</head>
<body>
    <div class="container">
    <div class="bro">
        <img width="400px" src="images/bro.jpg" alt="no image ">
    </div>
      <div class="personal_info">
          <div class="info">
              <div class="detail_info">
                <span>id:<?php echo $id ?> </span><br>
                <span>name:<?php echo $name ?> </span><br>
                <span>age:<?php echo $age ?> </span><br>
                <span>sex:<?php echo $sex ?> </span><br>
                <span>type:<?php echo $type ?> </span><br>
                <span>many:<?php echo $many ?> </span><br>
                <span>unit:<?php echo $unit ?> </span><br>
                <span>email:<?php echo $email ?> </span><br>
                <span>phone:<?php echo $phone ?> </span><br>
                <span>address:<?php echo $address ?> </span><br>
                <span>date:<?php echo $date ?> </span><br>
                </div>
                   <?php echo "<img  object-fit= cover height=190px width=190px src='images/".$image."'>"  ;?>  
                   </div>
                   <?php echo "<img  object-fit= cover height=190px width=190px src='".$qr."' alt='no qr genereted'>"  ;?>
                   </div>
                   </div>
         <a href="edit.php">Edit</a>
         <a href="login.php">logout</a>
        <?php echo "<a href='$qr' download>get qrcode   </a>"?>
</body>

</html>