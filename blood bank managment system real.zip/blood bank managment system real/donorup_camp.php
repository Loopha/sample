<?php 

$id = "";
$name = "";
$age = "";
$sex = "";
$type = "";
$many = "";
$unit = "";
$email = "";
$phone = "";
$address = "";
$date = "";
$image="";
if(isset($_POST['find'])){
  require_once "connect.php";
 $name1 = $_POST["name"];
 $query = "SELECT * FROM `donors` WHERE `name` = '$name1' LIMIT 1";
 $result = mysqli_query($connect,$query);
  while ($row =mysqli_fetch_array($result)){
    $id = $row ["id"];
    $name = $row ["name"];
    $age = $row ["age"];
    $sex = $row ["sex"];
    $type = $row ["type"];
    $many = $row ["how many"];
    $unit = $row ["unit"];
    $email = $row ["email"];
    $phone = $row ["phone"];
    $address = $row ["address"];
    $image = $row ["image"];   
    $date = $row ["date"]; 

  }
mysqli_free_result($result);
mysqli_close($connect);
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="search.css?v=<?php echo time(); ?>">
    <title>Document</title>
</head>
<body>
<header>
    <div class="name" >
             <nav class="navbar">
                 <ul>
                     <li><a class="active" href="camp.php">HOME</a>
                        <li><a href="#"><i class="fa fa-person"></i>DONOR</a>
                            <div class="sub-menu-1">
                               <ul>                              
                                  <li><a href="donor_camp.php"><i class="fas fa-user-plus"></i></i>add</a></li>
                                  <li><a href="donorup_camp.php"><i class="far fa-edit"></i></i>update</a></li> 
                              </ul>
                            </div>
                      </li>
                            <li><a href="#">REPORT</a>
                                <li><a href="login.php">LOGOUT</a> 
                     </li>
                 </ul>
             </nav>
             </div>
        </div> 
    </header>
<div class="search-container">
            <form action = "donorup_camp.php" method="POST">
              <input type="text" name="name" id="text" >
              <button id="button" type="submit" name="find" value="search donor">search</button>
            </form>
            <div class="display">
                <div class="info">
                <span>id:<?php echo $id ?> </span><br>
                <span>name:<?php echo $name ?> </span><br>
                <span>age:<?php echo $age ?> </span><br>
                <span>sex:<?php echo $sex ?> </span><br>
                <span>type:<?php echo $type ?> </span><br>
                <span>many:<?php echo $many ?> </span><br>
                <span>unit:<?php echo $unit ?> </span><br>
                <span>email:<?php echo $email ?> </span><br>
                <span>phone:<?php echo $phone ?> </span><br>
                <span>address:<?php echo $address ?> </span><br>
                <span>date:<?php echo $date ?> </span><br>
                </div>
                <div class="photo">
                   <?php echo "<img  object-fit= cover height=190px width=190px src='images/".$image."'>"  ;?>
                </div>
              </div>
         </div>
    </div>
    </body>
<style>
    .navbar {
  height: 80px;
  width: 100%;
  background: rgba(0, 0, 0, 0.4);
}
.looogo {
  width: 140px;
  height: auto;
  padding: 20px 100px;
}
.navbar ul {
  float: right;
  margin-right: 20px;
}
.navbar ul li {
  list-style: none;
  margin: 0 8px;
  display: inline-block;
  line-height: 80px;
}
.navbar ul li a {
  text-decoration: none;
  color: white;
  font-size: 20px;
  font-family: "Roboto", sans-serif;
}
.navbar ul li a.active,
.navbar ul li a:hover {
  background: red;
  border-radius: 2px;
}
.wrapper .center {
  position: absolute;
  left: 50%;
  top: 55%;
  transform: translate(-50%, -50%);
  font-family: sans-serif;
  user-select: none;
}
.sub-menu-1 {
  display: none;
}
.name ul li:hover .sub-menu-1 {
  display: block;
  position: absolute;
  background-color: rgb(100, 97, 97);
  margin-top: -5px;
  margin-left: -15px;
}
.name ul li:hover .sub-menu-1 ul {
  display: block;
  margin: 10px;
}
.name ul li:hover .sub-menu-1 ul li {
  width: 100px;
  padding: 10px;
  border-bottom: 1px dotted rgb(77, 73, 73);
  background: transparent;
  border-radius: 0;
  text-align: left;
}
.name ul li:hover .sub-menu-1 ul li:last-child {
  border-bottom: none;
}
.name ul li:hover .sub-menu-1 ul li a:hover {
  color: rgb(230, 43, 43);
}</style>
</html>