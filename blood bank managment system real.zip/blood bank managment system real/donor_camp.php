<?php
if(isset($_POST['insert'])){
  $traget = "images/".basename($_FILES['image']['name']);
  require_once "connect.php";
  //get values from the form.
    $name = $_POST["name"];
    $age = $_POST["age"];
    $sex = $_POST["sex"];
    $type = $_POST["type"];
    $many = $_POST ["many"];
    $unit = $_POST["unit"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $address = $_POST["address"];
    $images = $_FILES["image"]["name"];
    $date = date('y-m-d H:i:s');
    //generating a passwor
    $inf = "$name$age$sex$type$many$unit$email$phone$address!#$%^&*(){}][";
    $genereated_password =substr(str_shuffle($inf),0,8);
    //generating qr code.
    include "phpqrcode/qrlib.php";
    QRcode::png("$genereated_password","$phone.png");
    $qrcode = "$phone.png";
    //insert into database tables.
    $query="UPDATE `store` SET  `unit` =unit +$unit  WHERE `Type` = '$type';INSERT INTO `donors`(`name`, `age`, `sex`, `type`, `how many`, `unit`, `email`, `phone`, `address`, `image`, `date`, `Qr code`, `password`) VALUES ('$name','$age','$sex','$type','$many','$unit','$email','$phone','$address','$images','$date','$qrcode','$genereated_password')";
    move_uploaded_file($_FILES['image']['tmp_name'],$traget);
    $result =mysqli_multi_query($connect,$query);
    if($result){
    echo '<script>alert ("registered sucessfuly")</script>';
    }
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="donor.css?v=<?php echo time(); ?>">
    <title>Document</title>
</head>
<body>
    <header>
    <div class="name" >
             <nav class="navbar">
                 <ul>
                     <li><a class="active" href="camp.php">HOME</a>
                        <li><a href="#"><i class="fa fa-person"></i>DONOR</a>
                            <div class="sub-menu-1">
                               <ul>                              
                                  <li><a href="donor_camp.php"><i class="fas fa-user-plus"></i></i>add</a></li>
                                  <li><a href="donorup_camp.php"><i class="far fa-edit"></i></i>update</a></li> 
                              </ul>
                            </div>
                      </li>
                            <li><a href="#">REPORT</a>
                                <li><a href="login.php">LOGOUT</a> 
                     </li>
                 </ul>
             </nav>
             </div>
        </div> 
    </header>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="container1">
        <span>Name</span> <input name="name" type="text" placeholder="name">
        <span>Age</span> <input name="age" type="text" placeholder="age">
        <span>Sex</span> <input name="sex" type="text" placeholder="sex">
        <span>Blood Type</span> <input name="type" type="text" placeholder="blood type">
        <span>times</span> <input name="many" type="text" placeholder="how many">
        <span>Unit</span> <input name="unit" type="text" placeholder="unit">
        <span>Email</span> <input name="email" type="text" placeholder="email">
        <span>Phone</span> <input name="phone" type="text" placeholder="phone">
        <span>Address</span> <input name="address" type="text" placeholder="address">
        <span>photo</span> <input name="image" type="file" >
        <button type="submit" name="insert" >Save</button>
        </div>
    </form>

</body>
<style>
    .navbar {
  height: 80px;
  width: 100%;
  background: rgba(0, 0, 0, 0.4);
}
.looogo {
  width: 140px;
  height: auto;
  padding: 20px 100px;
}
.navbar ul {
  float: right;
  margin-right: 20px;
}
.navbar ul li {
  list-style: none;
  margin: 0 8px;
  display: inline-block;
  line-height: 80px;
}
.navbar ul li a {
  text-decoration: none;
  color: white;
  font-size: 20px;
  font-family: "Roboto", sans-serif;
}
.navbar ul li a.active,
.navbar ul li a:hover {
  background: red;
  border-radius: 2px;
}
.wrapper .center {
  position: absolute;
  left: 50%;
  top: 55%;
  transform: translate(-50%, -50%);
  font-family: sans-serif;
  user-select: none;
}
.sub-menu-1 {
  display: none;
}
.name ul li:hover .sub-menu-1 {
  display: block;
  position: absolute;
  background-color: rgb(100, 97, 97);
  margin-top: -5px;
  margin-left: -15px;
}
.name ul li:hover .sub-menu-1 ul {
  display: block;
  margin: 10px;
}
.name ul li:hover .sub-menu-1 ul li {
  width: 100px;
  padding: 10px;
  border-bottom: 1px dotted rgb(77, 73, 73);
  background: transparent;
  border-radius: 0;
  text-align: left;
}
.name ul li:hover .sub-menu-1 ul li:last-child {
  border-bottom: none;
}
.name ul li:hover .sub-menu-1 ul li a:hover {
  color: rgb(230, 43, 43);
}
</style>
</html>