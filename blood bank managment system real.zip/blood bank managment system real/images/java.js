const mi = document.querySelector('.mi')
const image = ['https://images.unsplash.com/photo-1615461066159-fea0960485d5?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8Ymxvb2QlMjBkb25hdGlvbnxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80','images/uio.jpg']
setInterval(function(){
    let random = Math.floor(Math.random()*2);
    mi.style.backgroundImage = `url("${image[random]}.jpg")`

},800);
