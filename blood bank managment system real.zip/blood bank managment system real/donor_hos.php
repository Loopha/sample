<?php
if(isset($_POST['insert'])){
  $traget = "images/".basename($_FILES['image']['name']);
  require_once "connect.php";
  //get values from the form.
    $name = $_POST["name"];
    $age = $_POST["age"];
    $sex = $_POST["sex"];
    $type = $_POST["type"];
    $many = $_POST ["many"];
    $unit = $_POST["unit"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $address = $_POST["address"];
    $images = $_FILES["image"]["name"];
    $date = date('y-m-d H:i:s');
    //generating a password.
    $inf = "$name$age$sex$type$many$unit$email$phone$address!#$%^&*(){}][";
    $genereated_password =substr(str_shuffle($inf),0,8);
    //generating qr code.
    include "phpqrcode/qrlib.php";
    QRcode::png("$genereated_password","$phone.png");
    $qrcode = "$phone.png";
    //insert into database tables.
    $query="UPDATE `store` SET  `unit` =unit +$unit  WHERE `Type` = '$type';INSERT INTO `donors`(`name`, `age`, `sex`, `type`, `how many`, `unit`, `email`, `phone`, `address`, `image`, `date`, `Qr code`, `password`) VALUES ('$name','$age','$sex','$type','$many','$unit','$email','$phone','$address','$images','$date','$qrcode','$genereated_password')";
    move_uploaded_file($_FILES['image']['tmp_name'],$traget);
    $result =mysqli_multi_query($connect,$query);
    if($result){
    echo '<script>alert ("registered sucessfuly")</script>';
    }
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="donor.css?v=<?php echo time(); ?>">
    
    <title>Document</title>
</head>
<body>
<header>
        <div class="menu"> 
       <ul>
        <li class="active "><a href="hospital.php"><i class="fa fa-home"></i> HOME</a></li>
        <li><a href="donor_hos.php"><i class="fa fa-person"></i>DONOR</a>
              <div class="sub-menu-1">
                 <ul> 
                    <li><a href="donor_hos.php"><i class="fas fa-user-plus"></i></i>add</a></li>
                    <li><a href="donorup_hos.php"><i class="far fa-edit"></i></i>update</a></li> 
                </ul>
              </div>
        </li>
        <li><a href="request.php"><i class="fa fa-share"></i>REQUEST</a></li>
        <li><a href="#"><i class="fa fa-sticky-note"></i>REPORT</a></li>
        <li><a href="index.php"><i class="fa fa-sign-out-alt"></i>LOGOUT</a></li>
       </ul>
        </div>   
        </header>  
         <form action="" method="post" enctype="multipart/form-data">
        <div class="container1">
        <span>Name</span> <input name="name" type="text" placeholder="name">
        <span>Age</span> <input name="age" type="text" placeholder="age">
        <span>Sex</span> <input name="sex" type="text" placeholder="sex">
        <span>Blood Type</span> <input name="type" type="text" placeholder="blood type">
        <span>times</span> <input name="many" type="text" placeholder="how many">
        <span>Unit</span> <input name="unit" type="text" placeholder="unit">
        <span>Email</span> <input name="email" type="text" placeholder="email">
        <span>Phone</span> <input name="phone" type="text" placeholder="phone">
        <span>Address</span> <input name="address" type="text" placeholder="address">
        <span>photo</span> <input name="image" type="file" >
        <button type="submit" name="insert" >Save</button>
        </div>
    </form>
</body>
<style>
  .menu
{
background-color: rgb(255, 255, 255);
text-align: center;
}
.menu ul
{
display: inline-flex;
list-style: none ;


}
.menu li
{
width: 120;
margin: 15px;
padding: 15px;
}
.menu ul li a
{
text-decoration: none;
color: rgb(231, 150, 0);
}
.active ,.menu ul li:hover
{
background-color: rgb(8, 8, 8);
border-radius: 3px;
}
.menu .fa
{
margin-right: 8px;
}
.sub-menu-1
{
display: none;
}
.menu ul li:hover .sub-menu-1
{
display: block;
position: absolute;
background-color:  rgb(255, 255, 255);
margin-top: 15px;
margin-left: -15px;
}
.menu ul li:hover .sub-menu-1 ul
{
display: block;
margin: 10px;
}
.menu ul li:hover .sub-menu-1 ul li 
{
width: 150px;
padding: 10px ;
border-bottom: 1px dotted #fff;
background: transparent;
border-radius: 0;
text-align: left;


}
.menu ul li:hover .sub-menu-1 ul li:last-child
{
border-bottom: none;

}
.menu ul li:hover .sub-menu-1 ul li a:hover
{
    color: rgb(12, 1, 1);
}
</style>
</html>