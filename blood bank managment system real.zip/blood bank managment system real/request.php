<?php
//insert.php
if(isset($_POST["post"]))
{
 include("connect.php");
   $subject = $_POST['subject'];
   $comment = $_POST['comment'];
 $query = "INSERT INTO comments (comment_subject,comment_text) VALUES ('$subject','$comment')";
 mysqli_query($connect, $query);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <title>Document</title>
</head>
<body>
<header>
        <div class="menu"> 
       <ul>
        <li class="active "><a href="hospital.php"><i class="fa fa-home"></i> HOME</a></li>
        <li><a href="#"><i class="fa fa-person"></i>DONOR</a>
              <div class="sub-menu-1">
                 <ul> 
                    <li><a href="donor_hos.php"><i class="fas fa-user-plus"></i></i>add</a></li>
                    <li><a href="donorup_hos.php"><i class="far fa-edit"></i></i>update</a></li> 
                </ul>
              </div>
        </li>
        <li><a href="request.php"><i class="fa fa-share"></i>REQUEST</a></li>
        <li><a href="#"><i class="fa fa-sticky-note"></i>REPORT</a></li>
        <li><a href="index.php"><i class="fa fa-sign-out-alt"></i>LOGOUT</a></li>
       </ul>
        </div>   
        </header>
    
<br />
   <h2 alig="center">Send a Request</h2>
   <br />
<form  method="post" id="comment_form">
    <div class="form-group">
     <label>Enter Hospital_Name</label>
     <input type="text" name="subject" id="subject" class="form-control">
    </div>
    <div class="form-group">
     <label>Enter A Request</label>
     <textarea name="comment" id="comment" class="form-control" rows="5"></textarea>
    </div>
    <div class="form-group">
     <input type="submit" name="post" id="post" class="btn btn-info" value="Post" />
    </div>
    
   </form>
</body>
<style>
  .menu
{
background-color: rgb(255, 255, 255);
text-align: center;
}
.menu ul
{
display: inline-flex;
list-style: none ;


}
.menu li
{
width: 120;
margin: 15px;
padding: 15px;
}
.menu ul li a
{
text-decoration: none;
color: rgb(231, 150, 0);
}
.active ,.menu ul li:hover
{
background-color: rgb(8, 8, 8);
border-radius: 3px;
}
.menu .fa
{
margin-right: 8px;
}
.sub-menu-1
{
display: none;
}
.menu ul li:hover .sub-menu-1
{
display: block;
position: absolute;
background-color:  rgb(255, 255, 255);
margin-top: 15px;
margin-left: -15px;
}
.menu ul li:hover .sub-menu-1 ul
{
display: block;
margin: 10px;
}
.menu ul li:hover .sub-menu-1 ul li 
{
width: 150px;
padding: 10px ;
border-bottom: 1px dotted #fff;
background: transparent;
border-radius: 0;
text-align: left;


}
.menu ul li:hover .sub-menu-1 ul li:last-child
{
border-bottom: none;

}
.menu ul li:hover .sub-menu-1 ul li a:hover
{
    color: rgb(12, 1, 1);
}
</style>
</html>