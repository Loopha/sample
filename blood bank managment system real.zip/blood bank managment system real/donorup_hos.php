<?php 

$id = "";
$name = "";
$age = "";
$sex = "";
$type = "";
$many = "";
$unit = "";
$email = "";
$phone = "";
$address = "";
$date = "";
$image="";
if(isset($_POST['find'])){
  require_once "connect.php";
 $name1 = $_POST["name"];
 $query = "SELECT * FROM `donors` WHERE `name` = '$name1' LIMIT 1";
 $result = mysqli_query($connect,$query);
  while ($row =mysqli_fetch_array($result)){
    $id = $row ["id"];
    $name = $row ["name"];
    $age = $row ["age"];
    $sex = $row ["sex"];
    $type = $row ["type"];
    $many = $row ["how many"];
    $unit = $row ["unit"];
    $email = $row ["email"];
    $phone = $row ["phone"];
    $address = $row ["address"];
    $image = $row ["image"];   
    $date = $row ["date"]; 

  }
mysqli_free_result($result);
mysqli_close($connect);
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="search.css?v=<?php echo time(); ?>">
    
    <title>update donor</title>
</head>
<body>
<header>
        <div class="menu"> 
       <ul>
        <li class="active "><a href="hospital.php"><i class="fa fa-home"></i> HOME</a></li>
        <li><a href="#"><i class="fa fa-person"></i>DONOR</a>
              <div class="sub-menu-1">
                 <ul> 
                    <li><a href="donor_hos.php"><i class="fas fa-user-plus"></i></i>add</a></li>
                    <li><a href="donorup_hos.php"><i class="far fa-edit"></i></i>update</a></li> 
                </ul>
              </div>
        </li>
        <li><a href="request.php"><i class="fa fa-share"></i>REQUEST</a></li>
        <li><a href="#"><i class="fa fa-sticky-note"></i>REPORT</a></li>
        <li><a href="index.php"><i class="fa fa-sign-out-alt"></i>LOGOUT</a></li>
       </ul>
        </div>   
        </header>
<div class="search-container">
            <form action = "donorup_hos.php" method="POST">
              <input type="text" name="name" id="text" >
              <button id="button" type="submit" name="find" value="search donor">search</button>
            </form>
            <div class="display">
                <div class="info">
                <span>id:<?php echo $id ?> </span><br>
                <span>name:<?php echo $name ?> </span><br>
                <span>age:<?php echo $age ?> </span><br>
                <span>sex:<?php echo $sex ?> </span><br>
                <span>type:<?php echo $type ?> </span><br>
                <span>many:<?php echo $many ?> </span><br>
                <span>unit:<?php echo $unit ?> </span><br>
                <span>email:<?php echo $email ?> </span><br>
                <span>phone:<?php echo $phone ?> </span><br>
                <span>address:<?php echo $address ?> </span><br>
                <span>date:<?php echo $date ?> </span><br>
                </div>
                <div class="photo">
                   <?php echo "<img  object-fit= cover height=190px width=190px src='images/".$image."'>"  ;?>
                </div>
              </div>
         </div>
    </div>
    
</body>
<style>
  .menu
{
background-color: rgb(255, 255, 255);
text-align: center;
}
.menu ul
{
display: inline-flex;
list-style: none ;


}
.menu li
{
width: 120;
margin: 15px;
padding: 15px;
}
.menu ul li a
{
text-decoration: none;
color: rgb(231, 150, 0);
}
.active ,.menu ul li:hover
{
background-color: rgb(8, 8, 8);
border-radius: 3px;
}
.menu .fa
{
margin-right: 8px;
}
.sub-menu-1
{
display: none;
}
.menu ul li:hover .sub-menu-1
{
display: block;
position: absolute;
background-color:  rgb(255, 255, 255);
margin-top: 15px;
margin-left: -15px;
}
.menu ul li:hover .sub-menu-1 ul
{
display: block;
margin: 10px;
}
.menu ul li:hover .sub-menu-1 ul li 
{
width: 150px;
padding: 10px ;
border-bottom: 1px dotted #fff;
background: transparent;
border-radius: 0;
text-align: left;


}
.menu ul li:hover .sub-menu-1 ul li:last-child
{
border-bottom: none;

}
.menu ul li:hover .sub-menu-1 ul li a:hover
{
    color: rgb(12, 1, 1);
}
</style>
</html>