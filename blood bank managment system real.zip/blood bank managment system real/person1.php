
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="person1.css?v=<?php echo time(); ?>">
    <title>person login</title>
</head>
<body>
    <div class="box">
        <h1>login </h1>
    <form action="person.php"  method="post">
        <input type="text" name="email1" placeholder="enter email or username">
        <input type="text" name="password" placeholder="enter passwords">
        <button value="submit" type="submit" name="ok">Login</button>
    </form>   
    </div>
</body>
</html>