<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Blood Bank MS</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <script src="java.js"></script>
    <script
      src="https://kit.fontawesome.com/6aa1d03493.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <div class="page-content">
   <header class = "header">
      <div class="header__links hide-for-mobile">
      <div class="nav">
          <a href="#" class = "logo">
          <img width = 150px height = 50px class="logo-image" src="images/blood.jpg" alt="">
          </a>
          <span class="main-name">Blood Bank</span>   
        <ul>
          <li><a href="admin.php">Home</a></li>
          <li><a href="#">Services <i class="fas fa-caret-down"></i></a>

            <ul class = "submenu">

              <li><a href="#">Donors</a>
                  <ul class = "submenu2">
                    <li><a href="Donor.php">Register </a></li>
                    <li><a href="search.php">Update</a></li>
                  </ul>
            </li>
              <li><a href="#">Hospital</a>
                  <ul class = "submenu2">
                    <li><a href="register_hos.php">Register</a></li>
                    <li><a href="update_hos.php">Update</a></li>
                  </ul>
            </li>
              <li><a href="#">Camp</a>
                    <ul class = "submenu2">
                      <li><a href="register_camp.php">Register</a></li>
                      <li><a href="update_camp.php">Update</a></li>
                    </ul>
            </li>
             
            </ul>
          </li>
          <li class = "notify-li"><a href="#" class = "dropdown-toggle" id = "notify"><span class="count" style = "background:red; margin-right:5px;"></span>Notification  
          <ul class="dropdown-menu"></ul></a>
          </li>
          <!-- <li><a href="#">Contact Us</a></li> -->
          <li><a href="index.php">Log Out</a></li>
        </ul>
      </div>
      </div>
   </header>       
   <div class="mi">
   <div class="slogan">
     <h2>Donate Blood & Save Life</h2>
     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat dolores deleniti, dolor, fuga, recusandae earum odit porro cum at blanditiis  voluptatibus! Veniam, alias id. Veniam vero nesciunt</p> 
   </div>
   </div>
   <main >
     <div class="middle">
     <div class="one com">
       <img src="images/donor.jpg" alt="">
      <h3>header one</h3>
      <p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Mollitia, doloribus. Excepturi amet  itaque mollitia sequi consectetur fugit laborum eos, corrupti eveniet nobis explicabo, velit omnis! Placeat quo itaque illum expedita.</p>
    </div> 
     <div class="two com">
     <img src="images/head blood.png" a lt="">
      <h3>header two</h3>
      <p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Mollitia, doloribus. Excepturi amet itaque mollitia sequi consectetur fugit laborum eos, corrupti eveniet nobis explicabo, velit omnis! Placeat quo itaque illum expedita.</p>
    </div> 
     <div class="three com">
     <img src="images/head blood.png" alt="">
      <h3>header three</h3>
      <p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Mollitia, doloribus. Excepturi amet itaque mollitia sequi consectetur fugit laborum eos, corrupti eveniet nobis explicabo, velit omnis! Placeat quo itaque illum expedita.</p>   
    </div> 
     <div class="four com">
     <img src="images/head blood.png" alt="">
      <h3>header four</h3>
      <p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Mollitia, doloribus. Excepturi amet itaque mollitia sequi consectetur fugit laborum eos, corrupti eveniet nobis explicabo, velit omnis! Placeat quo itaque illum expedita.</p>   
    </div> 
    <div class="five com">
     <img src="images/head blood.png" alt="">
      <h3>header five</h3>
      <p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Mollitia, doloribus. Excepturi amet itaque mollitia sequi consectetur fugit laborum eos, corrupti eveniet nobis explicabo, velit omnis! Placeat quo itaque illum expedita.</p>    
    </div>
    <div class="six com">
     <img src="images/head blood.png" alt="">
      <h3>header six</h3>
      <p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Mollitia, doloribus. Excepturi amet itaque mollitia sequi consectetur fugit laborum eos, corrupti eveniet nobis explicabo, velit omnis! Placeat quo itaque illum expedita.</p>    
    </div>
     </div> 
   </main>
  <section class="save">
     <h1>save three people with one unit of your blood! </h1>
   </section>
   </div>
  <footer>
      <div class="left icons">      
      <i class="fa fa-map-marker" aria-hidden="true">Ethiopia addis abeba</i>
      <i class="fa fa-phone" aria-hidden="true">+25112345</i>
      <i class="fa fa-envelope-o" aria-hidden="true"><a href="mailto:" id = "f_link">blood@gmail.com</a></i>   
      </div>
      <div class="right">
          <h5>about the company</h5>
          <p>Lorem ipsum, dolor sit amet consectetur  adipisicing elit. Veniam, architecto? 
          Lorem ipsum, dolor sit amet consectetur  adipisicing elit. Veniam, architecto?</p>
        <div class="icons">
        <i class="fa fa-facebook" aria-hidden="true"></i>
        <i class="fa fa-twitter" aria-hidden="true"></i>
        <i class="fa fa-telegram" aria-hidden="true"></i>
        </div>
      </div>
  </footer>
  </body>
  
<script>
$(document).ready(function(){
 
 function load_unseen_notification(view = '')
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{view:view},
   dataType:"json",
   success:function(data) 
   {
    $('.dropdown-menu').html(data.notification);
    if(data.unseen_notification > 0)
    {
     $('.count').html(data.unseen_notification);
    }
   }
  });
 }
 
 load_unseen_notification();
 
 $('#comment_form').on('submit', function(event){
  event.preventDefault();
  if($('#subject').val() != '' && $('#comment').val() != '')
  {
   var form_data = $(this).serialize();
   $.ajax({
    url:"insert.php",
    method:"POST",
    data:form_data,
    success:function(data)
    {
     $('#comment_form')[0].reset();
     load_unseen_notification();
    }
   });
  }
  else
  {
   alert("Both Fields are Required");
  }
 });
 
 $(document).on('click', '.dropdown-toggle', function(){
  $('.count').html('');
  load_unseen_notification('yes');
 });
 
 setInterval(function(){ 
  load_unseen_notification(); 
 }, 5000);
 
});
</script>


