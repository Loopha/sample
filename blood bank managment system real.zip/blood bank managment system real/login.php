<?php
    require_once "connect.php"; 
    $msg = "";
    session_start();

     
if(isset($_POST['login'])){
    $name = $_POST["username"];
    $password = $_POST["password"];
    $_SESSION['name'] = $_POST['username'];
    $_SESSION['password'] = $_POST['password'];
    $role = filter_input(INPUT_POST, 'usertype', FILTER_SANITIZE_STRING);
    $role = $_POST["usertype"];
    switch ($role){
        case "admin":
            if( $name =='adama'&& $password == '12345678'){
            header("Location: admin.php");
            }
            break;
        case "hospital":
            $query = "SELECT * FROM `hospital` WHERE `Hospital_Name` = '$name' AND `Password` = '$password'";
            $result = mysqli_query($connect,$query);
            if (mysqli_num_rows($result) == 0) {
                $msg = "Incorrect username or password!";           
            }
            else if(mysqli_num_rows($result) != 0){
            header("Location: hospital.php");
            }
            break;
        case "camp";
            $query = "SELECT * FROM `camp` WHERE `camp_name` = '$name' AND `Password` = '$password'";
            $result = mysqli_query($connect,$query);
            if (mysqli_num_rows($result) == 0) {
                $msg = "Incorrect username or password!";           
            }
            else if(mysqli_num_rows($result) != 0){
            header("Location: camp.php");
            }
            break;
        case "donor": 
            $query = "SELECT * FROM `Donors` WHERE `name` = '$name' AND `Password` = '$password'";
            $result = mysqli_query($connect,$query);
            if (mysqli_num_rows($result) == 0) {
                $msg = "Incorrect username or password!";          
            }
            else if(mysqli_num_rows($result) != 0){
            header("Location: donor_page.php");
            }
            break;    
        default:
            $msg = "Invalid User!"; 
    }
}
    

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
    <link rel="stylesheet" href="login.css?v= <?php echo time(); ?>">
    
</head>
<body>
    <div class="form">
    <form action = "login.php" method = "post">
        <h1>LOGIN</h1>
        <?php if($msg != ''): ?>
            <div class="alert"><?php echo $msg; ?></div>
        <?php endif; ?>

        <label for="username">Username</label>
        <input type="text" name="username" id="" value ="">

        <label for="password">Password</label>
        <input type="password" name="password" id="" >

        <label for="usertype">User Type</label>
        <select name="usertype" id="">
            <option value="admin">admin</option>
            <option value="hospital">hospital</option>
            <option value="camp">camp</option>
            <option value="donor">donor</option>
        </select>

        <button type="submit" name= "login">Login</button>

    </form>
    </div>

</body>
</html>