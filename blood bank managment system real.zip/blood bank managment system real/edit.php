<?php
//update personal informaion
if (isset ($_POST['update'])){
    require_once "connect.php";
    session_start();
    $id = $_SESSION['password'];    
    $name = $_POST['name'];
    $age = $_POST['age'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $image = $_POST['image'];
    $password = $_POST['password'];
    include "phpqrcode/qrlib.php" ;
    QRcode::png("$phone","$phone.png");
    $qrcode = "$phone.png";
    $update_query = "UPDATE `donors` SET `name`='$name',`age`='$age',`email`='$email',`phone`='$phone',`address`='$address',`image`='$image',`Qr code`='$qrcode' WHERE `id` =$id";
    if(mysqli_query($connect,$update_query)){
       echo"</script>alert ('updated successfully.');</script>";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edit personal informaion</title>
</head>
<body>
     <form action="" method="POST">
         <input type="text" name="name">
         <input type="text" name="age">
         <input type="text" name="email">
         <input type="text" name="phone">
         <input type="text" name="address">
         <input type="file" name="image">
         <input type="text" name="password">
         <button type="submit" name="update">update</button>
     </form>
</body>
</html>